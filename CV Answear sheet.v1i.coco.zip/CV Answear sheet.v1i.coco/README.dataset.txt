# CV Answear sheet > 2025-03-14 5:07pm
https://universe.roboflow.com/mudassir-abbassi-71xvf/cv-answear-sheet

Provided by a Roboflow user
License: CC BY 4.0

